package ru.aviasales.expandedlistview.interfaces;

public interface OnSomethingChange {
	void onChange();
}

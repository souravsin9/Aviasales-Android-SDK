package ru.aviasales.template.ui.listener;

public interface BaseDialogInterface {

	String getFragmentTag();
}

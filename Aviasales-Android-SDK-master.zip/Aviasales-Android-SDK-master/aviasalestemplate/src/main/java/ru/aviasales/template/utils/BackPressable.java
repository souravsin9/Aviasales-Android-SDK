package ru.aviasales.template.utils;

public interface BackPressable {
	boolean onBackPressed();
}

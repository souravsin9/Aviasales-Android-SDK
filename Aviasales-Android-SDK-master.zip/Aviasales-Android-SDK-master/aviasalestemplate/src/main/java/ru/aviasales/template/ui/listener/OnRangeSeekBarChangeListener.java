package ru.aviasales.template.ui.listener;

public interface OnRangeSeekBarChangeListener {
	void onChange(int min, int max);
}
